<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'furnikit');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'U76>hcR_lQ6^o1k-Bo#g7aPzi&glJ& C,AbC5^PW^Td/1&kBeN]T]^eh9li}|@SA');
define('SECURE_AUTH_KEY',  '4{sZbT&2}W^G}_%8 i3bvR LygqX_KQ+J6blb,Xy8N|;U<we(D/e.v-B/z)&(XYD');
define('LOGGED_IN_KEY',    ',n=K3mi(4a`y @-Ax&fhnN**Z`PyfTQ5f%-2Y<j%?snF_3:$#GdQA3) &#c(_k#v');
define('NONCE_KEY',        '&7*wML%lCt*mIXt?O,=L]s,{~Hl!;g4RQ|!>RyG}2^|/?r53Hk|V|C*3H|(Y0KoW');
define('AUTH_SALT',        'Y}a%=N>t;ss;Wb@c[MWF)itW0Jl%.}i)z`nI#74Xw~^TM)*Pj==[SGGJk/,[IB7>');
define('SECURE_AUTH_SALT', ':)WqM(;L2{~chYi}ML^woyUy*tr@o-M)./Q#86 Q}A!xZ=boWSz^W6HVohwa_Oa#');
define('LOGGED_IN_SALT',   '%!AzeZc8_6Df|WssaI:(Fqe,07kEk=aO|%E{Ei++{y,%vwVXd=b`!uX,HXD1a9A/');
define('NONCE_SALT',       'snx/ZP].i^w%:06*m)P~!zsKhSx9,+^;>=R~:URG?GiZ!1#%;%6`_)55~bw5f36*');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
define('WP_MEMORY_LIMIT', '256M');
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
